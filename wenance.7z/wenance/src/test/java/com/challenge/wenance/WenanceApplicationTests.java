package com.challenge.wenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WenanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
